# Do Vision-Language Transformers Exhibit Visual Commonsense? An Empirical Study of VCR
This is the repo for paper _Do Vision-Language Transformers Exhibit Visual Commonsense? An Empirical Study of VCR_. In this paper, we carefully studied the 
shortcomings of existing VL Transformers and designed several experiments to verify our hypotheses.

This repo currently supports all our experiments on different VL Transformers ([UNITER](https://github.com/ChenRocks/UNITER),
[VILLA](https://github.com/zhegan27/VILLA), [VL-BERT](https://github.com/jackroos/VL-BERT) and [ViLBERT](https://github.com/jiasenlu/vilbert_beta)).
You can go to their folders for detailed instructions. 