# Do Vision-Language Transformers Exhibit Visual Commonsense?
This repo is based on [uniter](https://github.com/ChenRocks/UNITER), you can refer to original repo for basic usage. 
In this repo, we conduct heavy experiments on __uniter__ to validate our findings. 
## VCR

### 1. Finetune w/o multimodal pretraining   
   ```
    horovodrun -np 4 python train_vcr.py --config config/train-vcr-base-bert_init-4gpu.json \
        --output_dir $VCR_EXP
   ```

### 2. Finetune w/o query/image
- __Remove query__: replace the import statement `from .vcr import ...` to `from .vcr_noquery import ...` 
 in file `data/__init__.py`. 
- __Remove image__:  replace the import statement `from .vcr import ...` to `from .vcr_noimg import ...` 
 in file `data/__init__.py`.

### 3. Finetune w/o tag input
- Replace the import statement `from .vcr import ...` to `from .vcr_notag import ...` 
    in file `data/__init__.py`.

### 4. Randomly replace tag
- Generate new textual dataset
    ```
    python prepro_vcr_random_replace_tags.py --annotations $ANNOT_PATH --split $SPLIT --output $OUTPUT_DIR 
    ```
- Train and test on new dataset using original commands. 

### 5. Joint/Seperate Finetuning on subtasks
- Option `--task` decides training on Q2A, QA2R or both. For example, training on Q2A task,
   ```
    horovodrun -np 4 python train_vcr.py --config config/train-vcr-base-4gpu.json \
        --output_dir $VCR_EXP --task qa
   ```
  
### 6. Attention statistics
- Store attention map produced on validation dataset. Each instance has a `input_ids`(textual tokens' id) and `attention`.
- Compute average attention weights in/cross different modalities.
    ```
    python utils/tv_attention.py
    ```
- Compute average attention weights where `[CLS]` is used for query.
    ```
    python utils/cls_attention.py
    ```
- Compute average attention weights and MRR of tags.
    ```
    python utils/tag_attention.py
    ```
