"""
Copyright (c) Microsoft Corporation.
Licensed under the MIT license.

preprocess NLVR annotations into LMDB
"""
import argparse
import json
import pickle
import os
from os.path import exists
import numpy as np

from cytoolz import curry
from tqdm import tqdm
from pytorch_pretrained_bert import BertTokenizer

from data.data import open_lmdb
import random


NAMES = ['Casey', 'Riley', 'Jessie', 'Jackie', 'Avery', 'Jaime', 'Peyton', 'Kerry', 'Jody', 'Kendall',
                        'Peyton', 'Skyler', 'Frankie', 'Pat', 'Quinn']


def generate_random_name(det_names, distribution=None):
    random_name = []
    objects, probs = distribution
    det_names = np.random.choice(objects, len(det_names), p=probs)
    for i, name in enumerate(det_names):
        if name == "person":
            word = f"person_{i}"
            # word = random.choice(NAMES)
        else:
            word = name
        random_name.append(word)

    return random_name


def replace_det_with_name(inputs, random_names):
    tokens = []
    id_tok2inp = []
    for i, w in enumerate(inputs):
        if isinstance(w, str):
            tokens.append(w)
            id_tok2inp.append(i)
        else:
            for j, idx in enumerate(w):
                if idx < len(random_names):
                    word = random_names[idx]
                else:
                    word = '[MASK]'
                tokens.append(word)
                id_tok2inp.append((i, j))
    return ' '.join(tokens), id_tok2inp


@curry
def bert_tokenize(tokenizer, text):
    tokens = []
    ids = []
    id2tok = []
    for i, word in enumerate(text.strip().split()):
        if word.startswith('person_'):
            ws = [word]
            # print(ws)
        else:
            ws = tokenizer.tokenize(word)
        if not ws:
            # some special char
            continue
        tokens.extend(ws)
        ids.extend(tokenizer.convert_tokens_to_ids(ws))
        id2tok.extend([i for _ in range(len(ws))])
    return tokens, ids, id2tok


def main(opts):
    if not exists(opts.output):
        os.makedirs(opts.output)
    else:
        raise ValueError('Found existing DB. Please explicitly remove '
                         'for re-processing')

    object_mapping = json.load(open('object_mapping.json'))
    meta = vars(opts)
    meta['tokenizer'] = opts.toker
    meta['bert'] = opts.toker
    # toker = BertTokenizer.from_pretrained(
    #     opts.toker, do_lower_case='uncased' in opts.toker)
    toker = BertTokenizer.from_pretrained(
        'data/vcr/bert-base-cased-vocab.txt', do_lower_case=False)
    # toker.add_special_tokens(json.load(open(f'data/vcr/txt_db/vcr_{args.split}.db/special_tokens.json')))
    tokenizer = bert_tokenize(toker)
    meta['UNK'] = toker.convert_tokens_to_ids(['[UNK]'])[0]
    meta['CLS'] = toker.convert_tokens_to_ids(['[CLS]'])[0]
    meta['SEP'] = toker.convert_tokens_to_ids(['[SEP]'])[0]
    meta['MASK'] = toker.convert_tokens_to_ids(['[MASK]'])[0]
    meta['v_range'] = (toker.convert_tokens_to_ids('!')[0],
                       len(toker.vocab))

    distribution = None
    with open(f'data/vcr/tag_category_distribution_in_image_{opts.split}.json') as fp:
        objects, probs = zip(*json.load(fp).items())
        probs = [i/sum(probs) for i in probs]
        distribution = (objects, probs)

    with open(f'{opts.output}/meta.json', 'w') as f:
        json.dump(vars(opts), f, indent=4)

    open_db = curry(open_lmdb, opts.output, readonly=False)
    output_field_name = ['id2len_qa', 'id2len_qar']
    with open_db() as db:

        with open(opts.annotations[0]) as jsonl:
            id2len_qa = {}
            id2len_qar = {}
            _jsonl = [json.loads(line) for line in jsonl]
            # txt2img = {}  # not sure if useful
            for example in tqdm(_jsonl, desc='processing VCR'):
                # example = json.loads(line)
                id_ = example['annot_id']
                img_id = example['img_fn'].split('/')[-1][:-4]
                img_fname = (f'vcr_gt_{args.split}_{img_id}.npz', f'vcr_{args.split}_{img_id}.npz')
                example['qa_target'] = example['answer_label']
                example['qar_target'] = example['rationale_label']
                example['object_ids'] = [object_mapping[o] for o in example['objects']]

                metadata_fn = json.load(
                    open(
                        os.path.join('data/vcr_raw', "vcr1images", example["metadata_fn"]), "r"
                    )
                )

                det_names = generate_random_name(metadata_fn["names"], distribution)

                raw_q, tok2inp_q = replace_det_with_name(example["question"], det_names)
                example['raw_q'] = raw_q
                example['tok2inp_q'] = tok2inp_q
                toked_question, input_ids, id2tok_q = tokenizer(example['raw_q'])
                example['toked_question'] = toked_question
                example['input_ids'] = input_ids
                example['id2tok_q'] = id2tok_q

                raw_as = []
                toked_as = []
                input_ids_as = []
                tok2inp_as = []
                id2tok_as = []
                for a in example['answer_choices']:
                    raw_a, tok2inp_a = replace_det_with_name(a, det_names)
                    tok2inp_as.append(tok2inp_a)
                    raw_as.append(raw_a)
                    toked_a, input_id_a, id2tok_a = tokenizer(raw_a)
                    toked_as.append(toked_a)
                    input_ids_as.append(input_id_a)
                    id2tok_as.append(id2tok_a)
                example['raw_as'] = raw_as
                example['toked_as'] = toked_as
                example['input_ids_as'] = input_ids_as
                example['tok2inp_as'] = tok2inp_as
                example['id2tok_as'] = id2tok_as

                raw_rs = []
                toked_rs = []
                input_ids_rs = []
                tok2inp_rs = []
                id2tok_rs = []
                for r in example['rationale_choices']:
                    raw_r, tok2inp_r = replace_det_with_name(r, det_names)
                    tok2inp_rs.append(tok2inp_r)
                    raw_rs.append(raw_r)
                    toked_r, input_id_r, id2tok_r = tokenizer(raw_r)
                    toked_rs.append(toked_r)
                    input_ids_rs.append(input_id_r)
                    id2tok_rs.append(id2tok_r)
                example['raw_rs'] = raw_rs
                example['toked_rs'] = toked_rs
                example['input_ids_rs'] = input_ids_rs
                example['tok2inp_rs'] = tok2inp_rs
                example['id2tok_rs'] = id2tok_rs

                # txt2img[id_] = img_fname
                # id2len[id_] = len(input_ids)
                id2len_qa[id_] = len(input_ids) + max([len(choice) for choice in input_ids_as])
                id2len_qar[id_] = len(input_ids) + len(input_ids_as[example['qa_target']]) + max([len(choice) for choice in input_ids_rs])

                example['img_fname'] = img_fname
                db[id_] = example
    jsons = [id2len_qa, id2len_qar]
    for dump, name in zip(jsons, output_field_name):
        with open(f'{opts.output}/{name}.json', 'w') as f:
            json.dump(dump, f)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--annotations', required=True, nargs='+',
                        help='annotation JSON')
    parser.add_argument('--split', required=True, choices=['train', 'val'])
    parser.add_argument('--output', required=True,
                        help='output dir of DB')
    parser.add_argument('--toker', default='bert-base-cased',
                        help='which BERT tokenizer to used')
    args = parser.parse_args()
    main(args)
