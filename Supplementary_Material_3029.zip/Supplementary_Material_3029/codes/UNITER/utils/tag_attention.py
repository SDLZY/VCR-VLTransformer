import numpy as np
import os
import pandas as pd
from tqdm.auto import tqdm
import json
import lmdb
import msgpack
from lz4.frame import decompress
import copy

DIRNAME = 'output/vcr/baseline_32000_130/attention'


def get_tag_encoding(example):
    toked_txt_region_tokens_qa = []
    toked_txt_region_tokens_qar = []
    for toked_txt_region_tokens_a in example['toked_txt_region_tokens_a']:
        toked_txt_region_tokens_qa.append([0] + copy.deepcopy(example['toked_txt_region_tokens']) + \
                         [0] + copy.deepcopy(toked_txt_region_tokens_a) + [0])
    for toked_txt_region_tokens_r in example['toked_txt_region_tokens_r']:
        toked_txt_region_tokens_qar.append([0] + copy.deepcopy(example['toked_txt_region_tokens']) + \
                                        [0] + copy.deepcopy(example['toked_txt_region_tokens_a'][example['qa_target']]) + \
                                        [0] + copy.deepcopy(toked_txt_region_tokens_r) + [0])
    return toked_txt_region_tokens_qa, toked_txt_region_tokens_qar


def get_tokens(example):
    toked_qa = []
    toked_qar = []
    for toked_a in example['toked_as']:
        toked_qa.append(['CLS'] + example['toked_question'] + ['SEP'] + toked_a + ['SEP'])
    for toked_r in example['toked_rs']:
        toked_qar.append(['CLS'] + example['toked_question'] + ['SEP'] + example['toked_as'][example['qa_target']]
                         + ['SEP'] + toked_r + ['SEP'])
    return toked_qa, toked_qar


def get_rank(arr):
    x = np.empty(arr.shape)
    _, _, n, m = arr.shape
    np.put_along_axis(x, np.argsort(arr)[:, :, :, ::-1], np.tile(np.arange(m), (12, 12, n, 1)), -1)
    return x


if __name__ == '__main__':
    results_qa = []
    results_qar = []
    rank_qa = []
    rank_qar = []
    env = lmdb.open('data/vcr/txt_db/vcr_val.db/', readonly=True, create=False)
    txn = env.begin(buffers=True)
    # for idx in tqdm(range(10)):
    for idx in tqdm(range(26534)):
        example = msgpack.loads(decompress(txn.get(f'val-{idx}'.encode())), raw=False)
        toked_txt_region_tokens_qas, toked_txt_region_tokens_qars = get_tag_encoding(example)
        toked_qas, toked_qars = get_tokens(example)
        for choice in range(4):
            path_qa = f'attention_map_qa_val-{idx}_{choice}.npy'
            path_qar = f'attention_map_qar_val-{idx}_{choice}.npy'

            data_qa = np.load(os.path.join(DIRNAME, path_qa), allow_pickle=True).item()
            data_qar = np.load(os.path.join(DIRNAME, path_qar), allow_pickle=True).item()

            att_qa = data_qa['attention']
            ids_qa = data_qa['input_ids']
            toked_qa = toked_qas[choice]
            toked_txt_region_tokens_qa = toked_txt_region_tokens_qas[choice]

            att_qar = data_qar['attention']
            ids_qar = data_qar['input_ids']
            toked_qar = toked_qars[choice]
            toked_txt_region_tokens_qar = toked_txt_region_tokens_qars[choice]

            # num_layers = att_qa.shape[0]
            num_layers = att_qar.shape[0]
            # print(num_layers)
            # print(att_qa.sum(-1))
            assert (np.abs(att_qa.sum(-1) - 1.) < 0.01).all()
            assert (np.abs(att_qar.sum(-1) - 1.) < 0.01).all()

            sep_pos_qa = np.where(ids_qa == 102)[0].tolist()[-1] + 1
            sep_pos_qar = np.where(ids_qar == 102)[0].tolist()[-1] + 1
            # import pdb; pdb.set_trace()

            att_t2o_qa = att_qa[:, :, :sep_pos_qa-1, sep_pos_qa:]
            att_o2t_qa = att_qa[:, :, sep_pos_qa:, :sep_pos_qa-1]
            rank_t2o_qa = get_rank(att_t2o_qa)
            rank_o2t_qa = get_rank(att_o2t_qa)

            att_t2o_qar = att_qar[:, :, :sep_pos_qar-1, sep_pos_qar:]
            att_o2t_qar = att_qar[:, :, sep_pos_qar:, :sep_pos_qar-1]
            rank_t2o_qar = get_rank(att_t2o_qar)
            rank_o2t_qar = get_rank(att_o2t_qar)

            # ======  q2a  ========
            assert len(toked_txt_region_tokens_qa) == ids_qa.shape[0] == len(toked_qa)
            for i, (toked_txt_region_token, id_, token) in enumerate(zip(toked_txt_region_tokens_qa, ids_qa, toked_qa)):
                assert toked_txt_region_token < 100
                if toked_txt_region_token == 0:
                    continue
                att_tok2obj = att_qa[:, :, i, sep_pos_qa + toked_txt_region_token].reshape(-1).tolist()
                att_obj2tok = att_qa[:, :, sep_pos_qa + toked_txt_region_token, i].reshape(-1).tolist()
                results_qa.append([idx, choice, i, token, 't2o'] + att_tok2obj)
                results_qa.append([idx, choice, i, token, 'o2t'] + att_obj2tok)
                rank_qa.append([idx, choice, i, token, 't2o'] +
                               rank_t2o_qa[:, :, i, toked_txt_region_token].reshape(-1).tolist())
                rank_qa.append([idx, choice, i, token, 'o2t'] +
                               rank_o2t_qa[:, :, toked_txt_region_token, i].reshape(-1).tolist())
                # import pdb; pdb.set_trace()

            # ======  qa2r  ========
            assert len(toked_txt_region_tokens_qar) == ids_qar.shape[0] == len(toked_qar)
            for i, (toked_txt_region_token, id_, token) in enumerate(zip(toked_txt_region_tokens_qar, ids_qar, toked_qar)):
                assert toked_txt_region_token < 100
                if toked_txt_region_token == 0:
                    continue
                att_tok2obj = att_qar[:, :, i, sep_pos_qar + toked_txt_region_token].reshape(-1).tolist()
                att_obj2tok = att_qar[:, :, sep_pos_qar + toked_txt_region_token, i].reshape(-1).tolist()
                results_qar.append([idx, choice, i, token, 't2o'] + att_tok2obj)
                results_qar.append([idx, choice, i, token, 'o2t'] + att_obj2tok)
                rank_qar.append([idx, choice, i, token, 't2o'] +
                                rank_t2o_qar[:, :, i, toked_txt_region_token].reshape(-1).tolist())
                rank_qar.append([idx, choice, i, token, 'o2t'] +
                                rank_o2t_qar[:, :, toked_txt_region_token, i].reshape(-1).tolist())

    results_qa = np.array(results_qa)
    results_qar = np.array(results_qar)
    columns = ['idx', 'choice', 'pos', 'token', 'direction'] + \
              [f'{i}_{j}' for i in range(12) for j in range(12)]
    df_qa = pd.DataFrame(results_qa, columns=columns)
    df_qar = pd.DataFrame(results_qar, columns=columns)
    df_qa.to_csv(os.path.join(os.path.dirname(DIRNAME), 'tag_att_qa.csv'))
    df_qar.to_csv(os.path.join(os.path.dirname(DIRNAME), 'tag_att_qar.csv'))
    print(df_qa)
    print(df_qar)
    df_rk_qa = pd.DataFrame(rank_qa, columns=columns)
    df_rk_qar = pd.DataFrame(rank_qar, columns=columns)
    df_rk_qa.to_csv(os.path.join(os.path.dirname(DIRNAME), 'tag_att_rank_qa.csv'))
    df_rk_qar.to_csv(os.path.join(os.path.dirname(DIRNAME), 'tag_att_rank_qar.csv'))
    print(df_rk_qa)
    print(df_rk_qar)

    results = []
    df_qa.set_index('direction', inplace=True)
    df_qar.set_index('direction', inplace=True)
    df_rk_qa.set_index('direction', inplace=True)
    df_rk_qar.set_index('direction', inplace=True)
    for drt in ['o2t', 't2o']:
        for layer in range(12):
            columns = [f'{layer}_{i}' for i in range(12)]
            results.append({
                'direction': drt,
                'layer': layer,
                'att_qa': df_qa.loc[drt, columns].mean().mean(),
                'att_qar': df_qar.loc[drt, columns].mean().mean(),
                'mrr_qa': (1 / (1 + df_rk_qa.loc[drt, columns])).mean().mean(),
                'mrr_qar': (1 / (1 + df_rk_qar.loc[drt, columns])).mean().mean(),
            })
    results = pd.DataFrame(results).set_index('direction')
    print(results)
    results.to_csv(os.path.join(model_dir, 'tag_att_mrr_vcr_32000.csv'))



