import numpy as np
import os
import pandas as pd
from tqdm.auto import tqdm
from joblib import Parallel, delayed

DIRNAME = 'output/vcr/baseline_32000_130/attention'

if __name__ == '__main__':
    all_att_map_qa = []
    all_att_map_qar = []
    # for idx in tqdm(range(100)):
    for idx in tqdm(range(26534)):
        for choice in range(4):
            path_qa = f'attention_map_qa_val-{idx}_{choice}.npy'
            path_qar = f'attention_map_qar_val-{idx}_{choice}.npy'

            data_qa = np.load(os.path.join(DIRNAME, path_qa), allow_pickle=True).item()
            data_qar = np.load(os.path.join(DIRNAME, path_qar), allow_pickle=True).item()

            att_qa = data_qa['attention']
            ids_qa = data_qa['input_ids']

            att_qar = data_qar['attention']
            ids_qar = data_qar['input_ids']

            # num_layers = att_qa.shape[0]
            num_layers = att_qar.shape[0]
            # print(num_layers)
            # print(att_qa.sum(-1))
            assert (np.abs(att_qa.sum(-1) - 1.) < 0.01).all()
            assert (np.abs(att_qar.sum(-1) - 1.) < 0.01).all()

            sep1_qa, sep2_qa = np.where(ids_qa == 102)[0].tolist()
            sep1_qar, sep2_qar, sep3_qar = np.where(ids_qar == 102)[0].tolist()
            slice_qa_q = slice(1, sep1_qa)
            slice_qa_a = slice(sep1_qa+1, sep2_qa)
            slice_qa_v = slice(sep2_qa+1, att_qa.shape[-1])
            length_qa_t = sep2_qa - 2
            length_qa_v = att_qa.shape[-1] - sep2_qa - 1
            att_map_qa = np.empty((*att_qa.shape[:2], 2, 2))

            att_map_qa[:, :, 0, 0] = (
                att_qa[:, :, slice_qa_q, slice_qa_q].sum((-1, -2)) +
                att_qa[:, :, slice_qa_q, slice_qa_a].sum((-1, -2)) +
                att_qa[:, :, slice_qa_a, slice_qa_q].sum((-1, -2)) +
                att_qa[:, :, slice_qa_a, slice_qa_a].sum((-1, -2))
            ) / length_qa_t

            att_map_qa[:, :, 0, 1] = (
                att_qa[:, :, slice_qa_q, slice_qa_v].sum((-1, -2)) +
                att_qa[:, :, slice_qa_a, slice_qa_v].sum((-1, -2))
            ) / length_qa_t

            att_map_qa[:, :, 1, 0] = (
                att_qa[:, :, slice_qa_v, slice_qa_q].sum((-1, -2)) +
                att_qa[:, :, slice_qa_v, slice_qa_a].sum((-1, -2))
            ) / length_qa_v

            att_map_qa[:, :, 1, 1] = (
                att_qa[:, :, slice_qa_v, slice_qa_v].sum((-1, -2))
            ) / length_qa_v

            slice_qar_q = slice(1, sep1_qar)
            slice_qar_a = slice(sep1_qar+1, sep2_qar)
            slice_qar_r = slice(sep2_qar+1, sep3_qar)
            slice_qar_v = slice(sep3_qar+1, att_qar.shape[-1])
            length_qar_t = sep3_qar - 3
            length_qar_v = att_qar.shape[-1] - sep3_qar - 1
            att_map_qar = np.empty((*att_qar.shape[:2], 2, 2))
            att_map_qar[:, :, 0, 0] = (
                att_qar[:, :, slice_qar_q, slice_qar_q].sum((-1, -2)) +
                att_qar[:, :, slice_qar_q, slice_qar_a].sum((-1, -2)) +
                att_qar[:, :, slice_qar_q, slice_qar_r].sum((-1, -2)) +
                att_qar[:, :, slice_qar_a, slice_qar_q].sum((-1, -2)) +
                att_qar[:, :, slice_qar_a, slice_qar_a].sum((-1, -2)) +
                att_qar[:, :, slice_qar_a, slice_qar_r].sum((-1, -2)) +
                att_qar[:, :, slice_qar_r, slice_qar_q].sum((-1, -2)) +
                att_qar[:, :, slice_qar_r, slice_qar_a].sum((-1, -2)) +
                att_qar[:, :, slice_qar_r, slice_qar_r].sum((-1, -2))
            ) / length_qar_t

            att_map_qar[:, :, 0, 1] = (
                att_qar[:, :, slice_qar_q, slice_qar_v].sum((-1, -2)) +
                att_qar[:, :, slice_qar_a, slice_qar_v].sum((-1, -2)) +
                att_qar[:, :, slice_qar_r, slice_qar_v].sum((-1, -2))
            ) / length_qar_t

            att_map_qar[:, :, 1, 0] = (
                att_qar[:, :, slice_qar_v, slice_qar_q].sum((-1, -2)) +
                att_qar[:, :, slice_qar_v, slice_qar_a].sum((-1, -2)) +
                att_qar[:, :, slice_qar_v, slice_qar_r].sum((-1, -2))
            ) / length_qar_v

            att_map_qar[:, :, 1, 1] = (
                att_qar[:, :, slice_qar_v, slice_qar_v].sum((-1, -2))
            ) / length_qar_v

            all_att_map_qa.append(att_map_qa)
            all_att_map_qar.append(att_map_qar)
    all_att_map_qa = np.array(all_att_map_qa)
    all_att_map_qar = np.array(all_att_map_qar)

    all_att_map_qa_mean = all_att_map_qa.mean((0, 1, 2))
    all_att_map_qar_mean = all_att_map_qar.mean((0, 1, 2))
    print(all_att_map_qa_mean)
    print(all_att_map_qar_mean)

    print("================standarize===================")

    print(all_att_map_qa_mean/all_att_map_qa_mean.sum(-1, keepdims=True))
    print(all_att_map_qar_mean/all_att_map_qar_mean.sum(-1, keepdims=True))

    np.save(os.path.join(DIRNAME, 'tv_att_map_wo_special_tokens_qa.npy'), all_att_map_qa)
    np.save(os.path.join(DIRNAME, 'tv_att_map_wo_special_tokens_qar.npy'), all_att_map_qar)




