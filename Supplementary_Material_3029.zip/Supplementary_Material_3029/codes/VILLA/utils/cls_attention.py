import numpy as np
import os
import pandas as pd
from tqdm.auto import tqdm
from joblib import Parallel, delayed

DIRNAME = 'output/vcr/baseline_32000_130/attention'
# DIRNAME = 'output/vcr_mask_sep_period_0526/attention'

if __name__ == '__main__':
    all_att_map_qa = []
    all_att_map_qar = []
    # for idx in tqdm(range(100)):
    for idx in tqdm(range(26534)):
        for choice in range(4):
            path_qa = f'attention_map_qa_val-{idx}_{choice}.npy'
            path_qar = f'attention_map_qar_val-{idx}_{choice}.npy'

            data_qa = np.load(os.path.join(DIRNAME, path_qa), allow_pickle=True).item()
            data_qar = np.load(os.path.join(DIRNAME, path_qar), allow_pickle=True).item()

            att_qa = data_qa['attention']
            ids_qa = data_qa['input_ids']

            att_qar = data_qar['attention']
            ids_qar = data_qar['input_ids']

            # num_layers = att_qa.shape[0]
            num_layers = att_qar.shape[0]
            # print(num_layers)
            # print(att_qa.sum(-1))
            assert (np.abs(att_qa.sum(-1) - 1.) < 0.01).all()
            assert (np.abs(att_qar.sum(-1) - 1.) < 0.01).all()

            sep1_qa, sep2_qa = np.where(ids_qa == 102)[0].tolist()
            sep1_qar, sep2_qar, sep3_qar = np.where(ids_qar == 102)[0].tolist()
            split_qa = [(0, 1), (1, sep1_qa), (sep1_qa, sep1_qa+1),
                        (sep1_qa+1, sep2_qa), (sep2_qa, sep2_qa+1),
                        (sep2_qa+1, att_qa.shape[-1])]
            split_qar = [(0, 1), (1, sep1_qar), (sep1_qar, sep1_qar+1),
                         (sep1_qar+1, sep2_qar), (sep2_qar, sep2_qar+1),
                         (sep2_qar+1, sep3_qar), (sep3_qar, sep3_qar+1),
                         (sep3_qar+1, att_qar.shape[-1])]
            # import pdb; pdb.set_trace()

            att_map_qa = np.empty((*att_qa.shape[:2], 6, 6))
            att_map_qar = np.empty((*att_qar.shape[:2], 8, 8))

            for i, (ibeg, iend) in enumerate(split_qa):
                for j, (jbeg, jend) in enumerate(split_qa):
                    att_map_qa[:, :, i, j] = att_qa[:, :, ibeg:iend, jbeg:jend].sum(-1).mean(-1)

            for i, (ibeg, iend) in enumerate(split_qar):
                for j, (jbeg, jend) in enumerate(split_qar):
                    att_map_qar[:, :, i, j] = att_qar[:, :, ibeg:iend, jbeg:jend].sum(-1).mean(-1)

            all_att_map_qa.append(att_map_qa)
            all_att_map_qar.append(att_map_qar)
    all_att_map_qa = np.array(all_att_map_qa)
    all_att_map_qar = np.array(all_att_map_qar)
    print(all_att_map_qa.mean((0, 1, 2)))
    print(all_att_map_qar.mean((0, 1, 2)))
    np.save(os.path.join(DIRNAME, 'qav_att_map_with_special_tokens.npy'), all_att_map_qa)
    np.save(os.path.join(DIRNAME, 'qarv_att_map_with_special_tokens.npy'), all_att_map_qar)


    att_cls_qa = all_att_map_qa[:, :, :, 0].mean((0, 2))
    att_cls_qar = all_att_map_qar[:, :, :, 0].mean((0, 2))

    att_cls_qa = pd.DataFrame(att_cls_qa, columns=['CLS', 'Q', 'SEP1', 'A', 'SEP2', 'V'])
    att_cls_qar = pd.DataFrame(att_cls_qar, columns=['CLS', 'Q', 'SEP1', 'A', 'SEP2', 'R', 'SEP3', 'V'])

    att_cls_qa_ = att_cls_qa[["CLS", "Q", "A", 'V']].values
    att_cls_qa_norm = att_cls_qa_/att_cls_qa_.sum(axis=1, keepdims=True)

    att_cls_qa_norm = pd.DataFrame(att_cls_qa_norm, columns=["CLS", "Q", "A", 'V'])
    print(att_cls_qa_norm)
    att_cls_qa_norm.to_csv(os.path.join(path, 'att_cls_qa_norm.csv'))

    # att_cls_qar = pd.read_csv(os.path.join(path, 'att_cls_qar.csv'), index_col=0)
    att_cls_qar_ = att_cls_qar[["CLS", "Q", "A", "R", 'V']].values
    att_cls_qar_norm = att_cls_qar_/att_cls_qar_.sum(axis=1, keepdims=True)

    att_cls_qar_norm = pd.DataFrame(att_cls_qar_norm, columns=["CLS", "Q", "A", "R", 'V'])
    print(att_cls_qar_norm)
    att_cls_qar_norm.to_csv(os.path.join(path, 'att_cls_qar_norm.csv'))


