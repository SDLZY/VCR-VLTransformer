# Do Vision-Language Transformers Exhibit Visual Commonsense?

This repo is based on [VL-BERT](https://github.com/jackroos/VL-BERT), you can refer to original repo for basic usage. 
In this repo, We provide the implementation code for each experiment in our paper on VL-BERT to validate our findings. 

### 1. Finetune w/o multimodal pretraining   
   ```
    python train_end2end.py --config cfgs/vcr/base_q2a_prec_wo_pretraining.yaml
   ```

### 2. Finetune w/o query/image
- __Remove query__: 
	```
    python train_end2end.py --config cfgs/vcr/base_q2a_prec_wo_query.yaml
   ```
- __Remove image__:  
	```
    python train_end2end.py --config cfgs/vcr/base_q2a_prec_wo_image.yaml
   ```

### 3. Finetune w/o tag input
- Replace the Dataset `DATASET_CATALOGS = {'vcr': VCRDataset}` to `DATASET_CATALOGS = {'vcr': VCRDataset_wo_tag}` 
    in the file `vcr/data/build.py`.

### 4. Randomly replace tags
- Replace the Dataset `DATASET_CATALOGS = {'vcr': VCRDataset}` to `DATASET_CATALOGS = {'vcr': VCRDatasetTagPlace}` 
    in the file `vcr/data/build.py`.

### 5. Joint/Seperate Finetuning on subtasks
- __Joint__:
   ```
    python train_end2end.py --config cfgs/vcr/base_q2a_qa2r_prec_train_together.yaml
   ```
- __Seperate__:
	- Question Answering:
	   ```
		python train_end2end.py --config cfgs/vcr/base_q2a_prec.yaml
	   ```
	- Answer Justification:
		```
		python train_end2end.py --config cfgs/vcr/base_qa2r_prec.yaml
	   ```
  
### 6. Attention statistics
You can calculate the relevant statistical value of attention by following these steps:
- You need to store the attention maps produced on validation dataset at first. Each instance has a `input_ids`(textual tokens' id) and `attention`. The `prepare_attention_statistic` function in `visual_linguistic_bert.py` and `numpy_save` function in `resnet_vlbert_for_vcr.py` can help you finish this quickly.
- Compute confusion matrix in Section 3.3.
    ```
    python vcr/itm.py
    ```
- Compute average attention weights where `[CLS]` is used for query.
    ```
    python vcr/cls_att.py
    ```
- Compute average attention weights and MRR of tags.
    ```
    python vcr/tag_attention_mrr.py
    ```
### 7. Proportion of correctly predicted instances from VL-BERT and the intersection of four states in VCR
You just need to save the logits for each sample and run `vcr/intersection.py`.
