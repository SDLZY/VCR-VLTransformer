import torch
from .eval_metric import EvalMetric
import numpy as np


class LossLogger(EvalMetric):
    def __init__(self, output_name, display_name=None,
                 allreduce=False, num_replicas=1):
        self.output_name = output_name
        if display_name is None:
            display_name = output_name
        super(LossLogger, self).__init__(display_name, allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            if self.output_name in outputs:
                self.sum_metric += float(outputs[self.output_name].mean().item())
            self.num_inst += 1

class CnnAccuracy(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(CnnAccuracy, self).__init__('CnnAcc', allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            cls_logits = outputs['cnn_reg_logits']
            label = outputs['objects']
            if cls_logits.dim() == 1:
                cls_logits = cls_logits.view((-1, 4))
                label = label.view((-1, 4)).argmax(1)
            self.sum_metric += float((cls_logits.argmax(dim=1) == label).sum().item())
            self.num_inst += cls_logits.shape[0]

class Q2ACnnAccuracy(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(Q2ACnnAccuracy, self).__init__('CnnAcc', allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            cls_logits = outputs['q2a_cnn_reg_logits']
            label = outputs['objects']
            if cls_logits.dim() == 1:
                cls_logits = cls_logits.view((-1, 4))
                label = label.view((-1, 4)).argmax(1)
            self.sum_metric += float((cls_logits.argmax(dim=1) == label).sum().item())
            self.num_inst += cls_logits.shape[0]


class QA2RCnnAccuracy(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(QA2RCnnAccuracy, self).__init__('CnnAcc', allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            cls_logits = outputs['qa2r_cnn_reg_logits']
            label = outputs['objects']
            if cls_logits.dim() == 1:
                cls_logits = cls_logits.view((-1, 4))
                label = label.view((-1, 4)).argmax(1)
            self.sum_metric += float((cls_logits.argmax(dim=1) == label).sum().item())
            self.num_inst += cls_logits.shape[0]

# class Accuracy(EvalMetric):
#     def __init__(self, allreduce=False, num_replicas=1):
#         super(Accuracy, self).__init__('Acc', allreduce, num_replicas)
#
#     def update(self, outputs):
#         with torch.no_grad():
#             _filter = outputs['label'] != -1
#             cls_logits = outputs['label_logits'][_filter]
#             label = outputs['label'][_filter]
#             if cls_logits.dim() == 1:
#                 cls_logits = cls_logits.view((-1, 4))
#                 label = label.view((-1, 4)).argmax(1)
#             self.sum_metric += float((cls_logits.argmax(dim=1) == label).sum().item())
#             self.num_inst += cls_logits.shape[0]

class AlignerAccuracy(EvalMetric):
    def __init__(self, task, allreduce=False, num_replicas=1):
        super(AlignerAccuracy, self).__init__(task + 'AlignerAcc', allreduce, num_replicas)
        self.task = task

    def update(self, outputs):
        with torch.no_grad():
            if self.task == 'Q2A':
                cls_logits = outputs['q2a_align_logits']
                label = outputs['answer_label']
            elif self.task == 'QA2R':
                cls_logits = outputs['qa2r_align_logits']
                label = outputs['rationale_label']
            else:
                raise ValueError("Not support task!")
            if cls_logits.dim() == 1:
                cls_logits = cls_logits.view((-1, 4))
                label = label.view((-1, 4)).argmax(1)
            self.sum_metric += float((cls_logits.argmax(dim=1) == label).sum().item())
            self.num_inst += cls_logits.shape[0]

class Accuracy(EvalMetric):
    def __init__(self, name='Acc', allreduce=False, num_replicas=1):
        super(Accuracy, self).__init__(name, allreduce, num_replicas)
        if name == 'Q2A_Acc':
            self.label_name = 'answer_label'
            self.logits_name = 'q2a_logits'
        elif name == 'QR2A_Acc':
            self.label_name = 'answer_label'
            self.logits_name = 'qr2a_logits'
        elif name == 'QA2R_Acc':
            self.label_name = 'rationale_label'
            self.logits_name = 'qa2r_logits'
        elif name == 'Q2A_Exchange_Acc':
            self.label_name = 'answer_label'
            self.logits_name = 'q2a_logits_exchange'
        elif name == 'QA2R_Exchange_Acc':
            self.label_name = 'rationale_label'
            self.logits_name = 'qa2r_logits_exchange'
        else:
            self.label_name = 'label'
            self.logits_name = 'label_logits'

    def update(self, outputs):
        with torch.no_grad():
            _filter = outputs[self.label_name] != -1
            cls_logits = outputs[self.logits_name][_filter]
            label = outputs[self.label_name][_filter]
            if cls_logits.dim() == 1:
                cls_logits = cls_logits.view((-1, 4))
                label = label.view((-1, 4)).argmax(1)
            self.sum_metric += float((cls_logits.argmax(dim=1) == label).sum().item())
            self.num_inst += cls_logits.shape[0]

class Q2ARAccuracy(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(Q2ARAccuracy, self).__init__('Q2AR_Acc', allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            _filter = outputs['answer_label'] != -1
            q2a_logits = outputs['q2a_logits'][_filter]
            answer_label = outputs['answer_label'][_filter]
            qa2r_logits = outputs['qa2r_logits'][_filter]
            rationale_label = outputs['rationale_label'][_filter]
            answer_hint = q2a_logits.argmax(dim=1) == answer_label
            rationale_hint = qa2r_logits.argmax(dim=1) == rationale_label
            self.sum_metric += float((answer_hint * rationale_hint).sum().item())
            self.num_inst += q2a_logits.shape[0]

class Q2AQR2AFraction(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(Q2AQR2AFraction, self).__init__('Q2AQR2AFraction', allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            _filter = outputs['answer_label'] != -1
            q2a_logits = outputs['q2a_logits'][_filter]
            answer_label = outputs['answer_label'][_filter]
            qr2a_logits = outputs['qr2a_logits'][_filter]
            q2a_hint = q2a_logits.argmax(dim=1) == answer_label
            qr2a_hint = qr2a_logits.argmax(dim=1) == answer_label
            self.sum_metric += float((q2a_hint * qr2a_hint).sum().item())
            self.num_inst += float(q2a_hint.sum().item())

class QA2RConditionAccuracy(EvalMetric):
    def __init__(self, name='QA2RConditionAccuracy', allreduce=False, num_replicas=1):
        super(QA2RConditionAccuracy, self).__init__(name, allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            hint_q2a = outputs['q2a_logits'].detach().cpu().numpy().argmax(1) == outputs['answer_label'].detach().cpu().numpy()
            hint_qa2r = outputs['qa2r_logits'].detach().cpu().numpy().argmax(1) == outputs['rationale_label'].detach().cpu().numpy()
            self.sum_metric += float(hint_qa2r[hint_q2a].sum().item())
            self.num_inst += float(hint_q2a.sum().item())


class AnsLoss(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(AnsLoss, self).__init__('AnsLoss', allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            self.sum_metric += float(outputs['ans_loss'].mean().item())
            self.num_inst += 1


class CNNRegLoss(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(CNNRegLoss, self).__init__('CNNRegLoss', allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            if 'cnn_regularization_loss' in outputs:
                self.sum_metric += float(outputs['cnn_regularization_loss'].mean().item())
            self.num_inst += 1


class PositiveFraction(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(PositiveFraction, self).__init__('PosFraction', allreduce, num_replicas)

    def update(self, outputs):
        with torch.no_grad():
            self.sum_metric += float(outputs['positive_fraction'].mean().item())
            self.num_inst += 1


class JointAccuracy(EvalMetric):
    def __init__(self, allreduce=False, num_replicas=1):
        super(JointAccuracy, self).__init__('JointAcc', allreduce, num_replicas)

    def update(self, outputs):
        a_cls_logits = outputs['answer_label_logits']
        a_label = outputs['answer_label']
        r_cls_logits = outputs['rationale_label_logits']
        r_label = outputs['rationale_label']
        self.sum_metric += float(((a_cls_logits.argmax(dim=1) == a_label)
                                  & (r_cls_logits.argmax(dim=1) == r_label)).sum().item())
        self.num_inst += a_cls_logits.shape[0]



