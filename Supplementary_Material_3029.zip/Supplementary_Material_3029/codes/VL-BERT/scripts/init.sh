#!/usr/bin/env bash

cd ./common/lib/roi_pooling/
python setup.py build_ext --inplace
cd ../../../

#cd ./refcoco/data/datasets/refer/
#make
#cd ../../../../



