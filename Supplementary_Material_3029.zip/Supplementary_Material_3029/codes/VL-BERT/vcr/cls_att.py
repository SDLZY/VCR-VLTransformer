import numpy as np
import os
import pandas as pd
from tqdm.auto import tqdm
import codecs
import json

# np.set_printoptions(threshold=1e6)
# pd.set_option('display.max_columns', None)
# pd.set_option('display.max_rows', None)
DIRNAME_QA = './output/vcr/q2a/base_q2a_prec_bs64_w-cnnloss/base_q2a_prec/vcr1images_train/vcr_val_attention_maps'
DIRNAME_QAR = './output/vcr/qa2r/base_qa2r_prec_bs64_w-cnnloss/base_qa2r_prec/vcr1images_train/vcr_val_attention_maps'

if __name__ == '__main__':
    df_qa = {'mean': [], 'sum': []}
    df_qar = {'mean': [], 'sum': []}
    reduce_method = {'mean': np.mean, 'sum': np.sum}
    with codecs.open('/vcr/question_len.json', 'r', encoding='utf8') as f:
        question_len_dict = json.load(f)

    for idx in tqdm(range(26534)):
        path_qa = f'attention_map_qa_val-{idx}.npz'
        path_qar = f'attention_map_qar_val-{idx}.npz'

        data_qa = np.load(os.path.join(DIRNAME_QA, path_qa))
        data_qar = np.load(os.path.join(DIRNAME_QAR, path_qar))

        # att_qa = data_qa['attention']
        # ids_qa = data_qa['input_ids']

        att_qar = data_qar['attention']
        ids_qar = data_qar['input_ids']

        num_layers = att_qar.shape[1]

        # assert (np.abs(att_qa.sum(-1) - 1.) < 0.01).all()
        assert (np.abs(att_qar.sum(-1) - 1.) < 0.01).all()
        question_len = question_len_dict[str(idx)]

        for choice_id in range(4):
            sep_pos_qar = np.where(ids_qar[choice_id] == 102)[0].tolist()
            end_pos_qar = np.where(ids_qar[choice_id] == 30526)[0].tolist()
            print(sep_pos_qar)

            query_len = sep_pos_qar[0] - 1
            response_len = sep_pos_qar[1] - sep_pos_qar[0] - 1
            object_len = end_pos_qar[0] - sep_pos_qar[1] - 1

            att_qar_cls = att_qar[choice_id, :, :, 0, 0]
            att_qar_q = np.sum(att_qar[choice_id, :, :, 0, 1:question_len], axis=-1)
            att_qar_a = np.sum(att_qar[choice_id, :, :, 0, question_len:sep_pos_qar[0]], axis=-1)
            att_qar_sep1 = att_qar[choice_id, :, :, 0, sep_pos_qar[0]]
            att_qar_r = np.sum(att_qar[choice_id, :, :, 0, sep_pos_qar[0]+1:sep_pos_qar[1]], axis=-1)
            att_qar_sep2 = att_qar[choice_id, :, :, 0, sep_pos_qar[1]]
            att_qar_v = np.sum(att_qar[choice_id, :, :, 0, sep_pos_qar[1] + 1:end_pos_qar[0]], axis=-1)
            att_qar_end = att_qar[choice_id, :, :, 0, end_pos_qar[0]]
            for i in range(num_layers):
                for j in range(num_layers):
                    df_qar['sum'].append({
                        'idx': idx,
                        'choice_id': choice_id,
                        'layer': i,
                        'head': j,
                        'att_qar_cls': att_qar_cls[i, j],
                        'att_qar_q': att_qar_q[i, j],
                        'att_qar_a': att_qar_a[i, j],
                        'att_qar_sep1': att_qar_sep1[i, j],
                        'att_qar_r': att_qar_r[i, j],
                        'att_qar_sep2': att_qar_sep2[i, j],
                        'att_qar_v': att_qar_v[i, j],
                        'att_qar_end': att_qar_end[i, j],
                    })

    df_qar_sum = pd.DataFrame(df_qar['sum'])
    #
    # df_qa_mean.to_csv(os.path.join(os.path.dirname(DIRNAME_QA), 'df_qa_mean.csv'), index=False)
    # df_qa_sum.to_csv(os.path.join(os.path.dirname(DIRNAME_QA), 'df_qa_sum.csv'), index=False)
    # df_qar_mean.to_csv(os.path.join(os.path.dirname(DIRNAME_QAR), 'df_qar_mean.csv'), index=False)
    df_qar_sum.to_csv(os.path.join(os.path.dirname(DIRNAME_QAR), 'df_qar_cls_sum.csv'), index=False)
    # print(df_qa_sum.groupby(['layer']).mean().drop(columns=['idx', 'head']))
    print(df_qar_sum.groupby(['layer']).mean().drop(columns=['idx', 'head']))
