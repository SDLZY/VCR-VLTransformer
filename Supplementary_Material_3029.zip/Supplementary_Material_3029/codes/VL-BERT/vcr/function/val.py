from collections import namedtuple
import torch
from common.trainer import to_cuda
import numpy as np


@torch.no_grad()
def do_validation(net, val_loader, metrics, label_index_in_batch):
    net.eval()
    metrics.reset()
    val_probs = []
    val_labels = []
    for nbatch, batch in enumerate(val_loader):
        batch = to_cuda(batch)
        label = batch[label_index_in_batch]
        datas = [batch[i] for i in range(len(batch)) if i != label_index_in_batch % len(batch)]

        outputs = net(*datas)
        outputs.update({'label': label})
        val_probs.append(outputs['label_logits'].detach().cpu().numpy())
        val_labels.append(outputs['label'].detach().cpu().numpy())
        metrics.update(outputs)
    val_labels = np.concatenate(val_labels, 0)
    val_probs = np.concatenate(val_probs, 0)
    np.save(f'val_logits_q2a_replace_tag_image_distribution.npy', val_probs)
    np.save(f'val_labels_q2a_replace_tag_image_distribution.npy', val_labels)

@torch.no_grad()
def do_validation_q2a_qr2a_qa2r(net, val_loader, metrics, label_index_in_batch):
    net.eval()
    metrics.reset()
    for nbatch, batch in enumerate(val_loader):
        batch = to_cuda(batch)
        answer_label = batch[label_index_in_batch[0]]
        rationale_label = batch[label_index_in_batch[1]]
        datas = [batch[i] for i in range(len(batch)) if (i != label_index_in_batch[0] % len(batch)) and (i != label_index_in_batch[1] % len(batch))]

        outputs = net(*batch)
        outputs.update({'answer_label': answer_label, 'rationale_label': rationale_label})
        metrics.update(outputs)

@torch.no_grad()
def do_validation_q2a_succeed_qa2r(net, val_loader, metrics, label_index_in_batch):
    net.eval()
    metrics.reset()
    for nbatch, batch in enumerate(val_loader):
        batch = to_cuda(batch)
        answer_label = batch[label_index_in_batch[0]]
        rationale_label = batch[label_index_in_batch[1]]
        datas = [batch[i] for i in range(len(batch)) if i != label_index_in_batch[1] % len(batch)]

        outputs = net(*datas)
        outputs.update({'answer_label': answer_label, 'rationale_label': rationale_label})
        metrics.update(outputs)

@torch.no_grad()
def joint_validation(answer_net, rationale_net, answer_val_loader, rationale_val_loader, metrics, label_index_in_batch,
                     show_progress=False):
    answer_net.eval()
    rationale_net.eval()
    metrics.reset()

    def step(a_batch, r_batch):
        a_batch = to_cuda(a_batch)
        a_label = a_batch[label_index_in_batch]
        a_datas = [a_batch[i] for i in range(len(a_batch)) if i != label_index_in_batch % len(a_batch)]
        r_batch = to_cuda(r_batch)
        r_label = r_batch[label_index_in_batch]
        r_datas = [r_batch[i] for i in range(len(r_batch)) if i != label_index_in_batch % len(r_batch)]

        a_outputs = answer_net(*a_datas)
        r_outputs = rationale_net(*r_datas)
        outputs = {'answer_' + k: v for k, v in a_outputs.items()}
        outputs.update({'rationale_' + k: v for k, v in r_outputs.items()})
        outputs.update({'answer_label': a_label,
                        'rationale_label': r_label})
        metrics.update(outputs)

    if show_progress:
        from tqdm import tqdm
        for a_batch, r_batch in tqdm(zip(answer_val_loader, rationale_val_loader)):
            step(a_batch, r_batch)
    else:
        for a_batch, r_batch in zip(answer_val_loader, rationale_val_loader):
            step(a_batch, r_batch)

@torch.no_grad()
def q2a_qr2a_proportion(net, val_loader, metrics, label_index_in_batch):
    net.eval()
    metrics.reset()
    for nbatch, batch in enumerate(val_loader):
        batch = to_cuda(batch)
        answer_label = batch[label_index_in_batch[0]]
        rationale_label = batch[label_index_in_batch[1]]
        datas = [batch[i] for i in range(len(batch)) if
                 (i != label_index_in_batch[0] % len(batch)) and (i != label_index_in_batch[1] % len(batch))]

        outputs = net(*datas)
        outputs.update({'answer_label': answer_label, 'rationale_label': rationale_label})
        metrics.update(outputs)