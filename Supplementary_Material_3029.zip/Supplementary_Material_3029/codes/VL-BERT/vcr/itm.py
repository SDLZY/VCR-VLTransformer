import numpy as np
import os
import pandas as pd
from tqdm.auto import tqdm

np.set_printoptions(threshold=1e6)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
DIRNAME_QA = '/vcr_val_attention_maps'
DIRNAME_QAR = '/vcr_val_attention_maps'

if __name__ == '__main__':
    df_qa = {'mean': [], 'sum': []}
    df_qar = {'mean': [], 'sum': []}
    reduce_method = {'mean': np.mean, 'sum': np.sum}

    for idx in tqdm(range(26534)):
        path_qa = f'attention_map_qa_val-{idx}.npz'
        path_qar = f'attention_map_qar_val-{idx}.npz'

        data_qa = np.load(os.path.join(DIRNAME_QA, path_qa))
        data_qar = np.load(os.path.join(DIRNAME_QAR, path_qar))

        att_qa = data_qa['attention']
        ids_qa = data_qa['input_ids']

        att_qar = data_qar['attention']
        ids_qar = data_qar['input_ids']

        num_layers = att_qa.shape[1]

        assert (np.abs(att_qa.sum(-1) - 1.) < 0.01).all()
        assert (np.abs(att_qar.sum(-1) - 1.) < 0.01).all()

        for reduce in ['sum']:

            for choice_id in range(4):
                sep_pos_qa = np.where(ids_qa[choice_id] == 102)[0].tolist()
                end_pos_qa = np.where(ids_qa[choice_id] == 30526)[0].tolist()

                query_len = sep_pos_qa[0] - 1
                response_len = sep_pos_qa[1] - sep_pos_qa[0] - 1
                object_len = end_pos_qa[0] - sep_pos_qa[1] - 1

                att_qa_q2q = reduce_method[reduce](att_qa[choice_id, :, :, 1:sep_pos_qa[0], 1:sep_pos_qa[0]], -1).mean(-1)      # shape [12, 12]
                att_qa_q2r = reduce_method[reduce](att_qa[choice_id, :, :, 1:sep_pos_qa[0], sep_pos_qa[0]+1:sep_pos_qa[1]], -1).mean(-1)
                att_qa_q2o = reduce_method[reduce](att_qa[choice_id, :, :, 1:sep_pos_qa[0], sep_pos_qa[1]+1:end_pos_qa[0]], -1).mean(-1)
                att_qa_r2q = reduce_method[reduce](att_qa[choice_id, :, :, sep_pos_qa[0]+1:sep_pos_qa[1], 1:sep_pos_qa[0]], -1).mean(-1)
                att_qa_r2r = reduce_method[reduce](att_qa[choice_id, :, :, sep_pos_qa[0]+1:sep_pos_qa[1], sep_pos_qa[0]+1:sep_pos_qa[1]], -1).mean(-1)
                att_qa_r2o = reduce_method[reduce](att_qa[choice_id, :, :, sep_pos_qa[0]+1:sep_pos_qa[1], sep_pos_qa[1]+1:end_pos_qa[0]], -1).mean(-1)
                att_qa_o2q = reduce_method[reduce](att_qa[choice_id, :, :, sep_pos_qa[1]+1:end_pos_qa[0], 1:sep_pos_qa[0]], -1).mean(-1)
                att_qa_o2r = reduce_method[reduce](att_qa[choice_id, :, :, sep_pos_qa[1]+1:end_pos_qa[0], sep_pos_qa[0]+1:sep_pos_qa[1]], -1).mean(-1)
                att_qa_o2o = reduce_method[reduce](att_qa[choice_id, :, :, sep_pos_qa[1]+1:end_pos_qa[0], sep_pos_qa[1]+1:end_pos_qa[0]], -1).mean(-1)
                for i in range(num_layers):
                    for j in range(num_layers):
                        df_qa[reduce].append({
                            'idx': idx,
                            'choice_id': choice_id,
                            'layer': i,
                            'head': j,
                            'att_qa_q2q': att_qa_q2q[i, j],
                            'att_qa_q2r': att_qa_q2r[i, j],
                            'att_qa_q2o': att_qa_q2o[i, j],
                            'att_qa_r2q': att_qa_r2q[i, j],
                            'att_qa_r2r': att_qa_r2r[i, j],
                            'att_qa_r2o': att_qa_r2o[i, j],
                            'att_qa_o2q': att_qa_o2q[i, j],
                            'att_qa_o2r': att_qa_o2r[i, j],
                            'att_qa_o2o': att_qa_o2o[i, j],
                        })

            for choice_id in range(4):
                sep_pos_qar = np.where(ids_qar[choice_id] == 102)[0].tolist()
                end_pos_qar = np.where(ids_qar[choice_id] == 30526)[0].tolist()

                query_len = sep_pos_qar[0] - 1
                response_len = sep_pos_qar[1] - sep_pos_qar[0] - 1
                object_len = end_pos_qar[0] - sep_pos_qar[1] - 1

                att_qar_q2q = reduce_method[reduce](att_qar[choice_id, :, :, 1:sep_pos_qar[0], 1:sep_pos_qar[0]], -1).mean(-1)
                att_qar_q2r = reduce_method[reduce](att_qar[choice_id, :, :, 1:sep_pos_qar[0], sep_pos_qar[0]+1:sep_pos_qar[1]], -1).mean(-1)
                att_qar_q2o = reduce_method[reduce](att_qar[choice_id, :, :, 1:sep_pos_qar[0], sep_pos_qar[1]+1:end_pos_qar[0]], -1).mean(-1)
                att_qar_r2q = reduce_method[reduce](att_qar[choice_id, :, :, sep_pos_qar[0]+1:sep_pos_qar[1], 1:sep_pos_qar[0]], -1).mean(-1)
                att_qar_r2r = reduce_method[reduce](att_qar[choice_id, :, :, sep_pos_qar[0]+1:sep_pos_qar[1], sep_pos_qar[0]+1:sep_pos_qar[1]], -1).mean(-1)
                att_qar_r2o = reduce_method[reduce](att_qar[choice_id, :, :, sep_pos_qar[0]+1:sep_pos_qar[1], sep_pos_qar[1]+1:end_pos_qar[0]], -1).mean(-1)
                att_qar_o2q = reduce_method[reduce](att_qar[choice_id, :, :, sep_pos_qar[1]+1:end_pos_qar[0], 1:sep_pos_qar[0]], -1).mean(-1)
                att_qar_o2r = reduce_method[reduce](att_qar[choice_id, :, :, sep_pos_qar[1]+1:end_pos_qar[0], sep_pos_qar[0]+1:sep_pos_qar[1]], -1).mean(-1)
                att_qar_o2o = reduce_method[reduce](att_qar[choice_id, :, :, sep_pos_qar[1]+1:end_pos_qar[0], sep_pos_qar[1]+1:end_pos_qar[0]], -1).mean(-1)
                for i in range(num_layers):
                    for j in range(num_layers):
                        df_qar[reduce].append({
                            'idx': idx,
                            'choice_id': choice_id,
                            'layer': i,
                            'head': j,
                            'att_qar_q2q': att_qar_q2q[i, j],
                            'att_qar_q2r': att_qar_q2r[i, j],
                            'att_qar_q2o': att_qar_q2o[i, j],
                            'att_qar_r2q': att_qar_r2q[i, j],
                            'att_qar_r2r': att_qar_r2r[i, j],
                            'att_qar_r2o': att_qar_r2o[i, j],
                            'att_qar_o2q': att_qar_o2q[i, j],
                            'att_qar_o2r': att_qar_o2r[i, j],
                            'att_qar_o2o': att_qar_o2o[i, j],
                        })
    # df_qa_mean = pd.DataFrame(df_qa['mean'])
    df_qa_sum = pd.DataFrame(df_qa['sum'])
    # df_qar_mean = pd.DataFrame(df_qar['mean'])
    df_qar_sum = pd.DataFrame(df_qar['sum'])

    # df_qa_mean.to_csv(os.path.join(os.path.dirname(DIRNAME_QA), 'df_qa_mean.csv'), index=False)
    df_qa_sum.to_csv(os.path.join(os.path.dirname(DIRNAME_QA), 'df_qa_sum.csv'), index=False)
    # df_qar_mean.to_csv(os.path.join(os.path.dirname(DIRNAME_QAR), 'df_qar_mean.csv'), index=False)
    df_qar_sum.to_csv(os.path.join(os.path.dirname(DIRNAME_QAR), 'df_qar_sum.csv'), index=False)
    print(df_qa_sum.groupby(['layer']).mean().drop(columns=['idx', 'head']))
    print(df_qar_sum.groupby(['layer']).mean().drop(columns=['idx', 'head']))
