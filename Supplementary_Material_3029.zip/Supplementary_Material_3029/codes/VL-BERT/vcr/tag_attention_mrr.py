import numpy as np
import os
import pandas as pd
from tqdm.auto import tqdm
import torch

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
DIRNAME_QA = '/output/vcr/q2a/base_q2a_prec_bs64_w-cnnloss/base_q2a_prec/vcr1images_train'
DIRNAME_QAR = '/output/vcr/qa2r/base_qa2r_prec_bs64_w-cnnloss/base_qa2r_prec/vcr1images_train'

if __name__ == '__main__':
    df_qa = {'txt2obj': [], 'obj2txt': []}
    df_qar = {'txt2obj': [], 'obj2txt': []}
    for idx in tqdm(range(26534)):
        path_mask_qa = f'about_tags_exp/tag_info_mask-{idx}.npz'
        path_mask_qar = f'about_tags_exp/tag_info_mask-{idx}.npz'
        path_att_qa = f'vcr_val_attention_maps/attention_map_qa_val-{idx}.npz'
        path_att_qar = f'vcr_val_attention_maps/attention_map_qar_val-{idx}.npz'

        data_mask_qa = np.load(os.path.join(DIRNAME_QA, path_mask_qa))
        data_mask_qar = np.load(os.path.join(DIRNAME_QAR, path_mask_qar))
        data_att_qa = np.load(os.path.join(DIRNAME_QA, path_att_qa))
        data_att_qar = np.load(os.path.join(DIRNAME_QAR, path_att_qar))

        text2obj_mask_qa = data_mask_qa['text2obj_mask']
        co_text2obj_mask_qa = data_mask_qa['co_text2obj_mask']
        obj2text_mask_qa = data_mask_qa['obj2text_mask']
        co_obj2text_mask_qa = data_mask_qa['co_obj2text_mask']

        text2obj_mask_qar = data_mask_qar['text2obj_mask']
        co_text2obj_mask_qar = data_mask_qar['co_text2obj_mask']
        obj2text_mask_qar = data_mask_qar['obj2text_mask']
        co_obj2text_mask_qar = data_mask_qar['co_obj2text_mask']

        att_qa = data_att_qa['attention']
        att_qar = data_att_qar['attention']

        num_layers = 12

        for choice_id in range(4):
            for i in range(num_layers):
                for j in range(num_layers):
                    text2obj_att_sum = co_text2obj_mask_qa[choice_id] * att_qa[choice_id, i, j]
                    row_index, colomn_index = np.nonzero(text2obj_att_sum)

                    text2obj_att_qa = att_qa[choice_id, i, j] * text2obj_mask_qa[choice_id]
                    text2obj_att_qa_tensor = torch.from_numpy(text2obj_att_qa)
                    obj_, obj_rank_idx = text2obj_att_qa_tensor.sort(dim=-1, descending=True)
                    _, obj_rank = obj_rank_idx.sort(dim=-1)
                    tag_rank = co_text2obj_mask_qa[choice_id] * obj_rank.numpy()

                    for row, colomn in zip(row_index, colomn_index):
                        df_qa['txt2obj'].append({
                            'idx': idx,
                            'choice_id': choice_id,
                            'layer': i,
                            'head': j,
                            'row': row,
                            'colomn': colomn,
                            'att_value': text2obj_att_sum[row, colomn],
                            'tag_rank': tag_rank[row, colomn]
                        })
        for choice_id in range(4):
            for i in range(num_layers):
                for j in range(num_layers):
                    text2obj_att_sum = co_text2obj_mask_qar[choice_id] * att_qar[choice_id, i, j]
                    row_index, colomn_index = np.nonzero(text2obj_att_sum)

                    text2obj_att_qar = att_qar[choice_id, i, j] * text2obj_mask_qar[choice_id]
                    text2obj_att_qar_tensor = torch.from_numpy(text2obj_att_qar)
                    obj_, obj_rank_idx = text2obj_att_qar_tensor.sort(dim=-1, descending=True)
                    _, obj_rank = obj_rank_idx.sort(dim=-1)
                    tag_rank = co_text2obj_mask_qar[choice_id] * obj_rank.numpy()

                    for row, colomn in zip(row_index, colomn_index):
                        df_qar['txt2obj'].append({
                            'idx': idx,
                            'choice_id': choice_id,
                            'layer': i,
                            'head': j,
                            'row': row,
                            'colomn': colomn,
                            'att_value': text2obj_att_sum[row, colomn],
                            'tag_rank': tag_rank[row, colomn]
                        })

    df_qa_txt2obj = pd.DataFrame(df_qa['txt2obj'])
    # df_qa_obj2txt = pd.DataFrame(df_qa['obj2txt'])
    df_qar_txt2obj = pd.DataFrame(df_qar['txt2obj'])

    df_qa_txt2obj.to_csv(os.path.join(DIRNAME_QA, 'df_qa_txt2obj_att_rank.csv'), index=False)
    # df_qa_obj2txt.to_csv(os.path.join(DIRNAME_QA, 'df_qa_obj2txt.csv'), index=False)
    df_qar_txt2obj.to_csv(os.path.join(DIRNAME_QA, 'df_qar_txt2obj_att_rank.csv'), index=False)
    # df_qar_obj2txt.to_csv(os.path.join(DIRNAME_QA, 'df_qar_obj2txt.csv'), index=False)
    print(df_qa_txt2obj.groupby(['layer']).mean().drop(columns=['idx', 'head', 'row', 'colomn']))
    # print(df_qa_obj2txt.groupby(['layer']).mean().drop(columns=['idx', 'head']))
    print(df_qar_txt2obj.groupby(['layer']).mean().drop(columns=['idx', 'head', 'row', 'colomn']))


