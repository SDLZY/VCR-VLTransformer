import os
import time

import h5py
import jsonlines
import json
import _pickle as cPickle
from PIL import Image
from copy import deepcopy

import torch
from torch.utils.data import Dataset
from external.pytorch_pretrained_bert import BertTokenizer, BasicTokenizer

from common.utils.zipreader import ZipReader
from common.utils.create_logger import makedirsExist
from common.utils.mask import generate_instance_mask
from common.nlp.misc import get_align_matrix
from common.utils.misc import block_digonal_matrix
from common.nlp.misc import random_word_with_token_ids
from common.nlp.roberta import RobertaTokenizer
import numpy as np
import codecs


def tag_categories_distribution_in_text():
    with open('cocoontology.json') as f:
        coco = json.load(f)
    coco_objects = [x['name'] for k, x in sorted(coco.items(), key=lambda x: int(  x[0]))]
    coco_obj_to_ind_train = {o: 0 for i, o in enumerate(coco_objects)}
    coco_obj_to_ind_val = {o: 0 for i, o in enumerate(coco_objects)}
    print(coco_obj_to_ind_train)
    with open('/train.jsonl', 'r') as f:
        items_train = [json.loads(s) for s in f]
    for item in items_train:
        for mixed_token in item['question']:
            if isinstance(mixed_token, list):
                tokens = [item['objects'][o] for o in mixed_token]
                for token in tokens:
                    coco_obj_to_ind_train[token] += 1
        for answer in item['answer_choices']:
            for mixed_token in answer:
                if isinstance(mixed_token, list):
                    tokens = [item['objects'][o] for o in mixed_token]
                    for token in tokens:
                        coco_obj_to_ind_train[token] += 1
        for rationale in item['rationale_choices']:
            for mixed_token in rationale:
                if isinstance(mixed_token, list):
                    tokens = [item['objects'][o] for o in mixed_token]
                    for token in tokens:
                        coco_obj_to_ind_train[token] += 1
    with open('val.jsonl', 'r') as f:
        items_val = [json.loads(s) for s in f]
    for item in items_val:
        for mixed_token in item['question']:
            if isinstance(mixed_token, list):
                tokens = [item['objects'][o] for o in mixed_token]
                for token in tokens:
                    coco_obj_to_ind_val[token] += 1
        for answer in item['answer_choices']:
            for mixed_token in answer:
                if isinstance(mixed_token, list):
                    tokens = [item['objects'][o] for o in mixed_token]
                    for token in tokens:
                        coco_obj_to_ind_val[token] += 1
        for rationale in item['rationale_choices']:
            for mixed_token in rationale:
                if isinstance(mixed_token, list):
                    tokens = [item['objects'][o] for o in mixed_token]
                    for token in tokens:
                        coco_obj_to_ind_val[token] += 1

    print(coco_obj_to_ind_train)
    print(coco_obj_to_ind_val)
    with codecs.open('tag_category_distribution_in_text_train.json', 'w', encoding='utf8') as f:
        json.dump(coco_obj_to_ind_train, f, ensure_ascii=True, indent=4)
    with codecs.open('tag_category_distribution_in_text_val.json', 'w', encoding='utf8') as f:
        json.dump(coco_obj_to_ind_val, f, ensure_ascii=True, indent=4)


def tag_categories_distribution_in_image():
    with open('cocoontology.json') as f:
        coco = json.load(f)
    coco_objects = [x['name'] for k, x in sorted(coco.items(), key=lambda x: int(  x[0]))]
    coco_obj_to_ind_train = {o: 0 for i, o in enumerate(coco_objects)}
    coco_obj_to_ind_val = {o: 0 for i, o in enumerate(coco_objects)}
    with open('train.jsonl', 'r') as f:
        items_train = [json.loads(s) for s in f]
    for item in items_train:
        for token in item['objects']:
            coco_obj_to_ind_train[token] += 1
    with open('val.jsonl', 'r') as f:
        items_val = [json.loads(s) for s in f]
    for item in items_val:
        for token in item['objects']:
            coco_obj_to_ind_val[token] += 1
    print(coco_obj_to_ind_train)
    print(coco_obj_to_ind_val)
    with codecs.open('tag_category_distribution_in_image_train.json', 'w', encoding='utf8') as f:
        json.dump(coco_obj_to_ind_train, f, ensure_ascii=True, indent=4)
    with codecs.open('tag_category_distribution_in_image_val.json', 'w', encoding='utf8') as f:
        json.dump(coco_obj_to_ind_val, f, ensure_ascii=True, indent=4)

if __name__ == '__main__':
    tag_categories_distribution_in_text()