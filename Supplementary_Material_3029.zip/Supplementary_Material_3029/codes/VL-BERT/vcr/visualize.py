import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import torch
import glob
from tqdm.auto import tqdm
import os




if __name__ == '__main__':
    SIZE = 3
    DIRNAME = 'output/vcr_mask_sep_0520'  
    attn_files = glob.glob(f'{DIRNAME}/attention/*')
    for filepath in tqdm(attn_files):
        #     continue
        figpath = os.path.join(DIRNAME, 'figures', os.path.basename(filepath).replace('.npy', '.png'))
        attn = np.load(filepath, allow_pickle=True).item()
        attentions = attn['attention']
        num_txt_tokens = attn['input_ids'].shape[0]
        comma_idx = np.where(attn['input_ids'] == 117)[0]
        period_idx = np.where(attn['input_ids'] == 119)[0]
        num_layers, num_heads = attentions.shape[:2]
        # print(attn['input_ids'])
        print(comma_idx)
        print(period_idx)
        fig, axes = plt.subplots(num_layers, num_heads, figsize=(num_heads*SIZE, num_layers*SIZE), sharex=True, sharey=True)
        for layer, attention in enumerate(attentions):
            for head in range(attention.shape[0]):
                sns.heatmap(attention[head], square=True, vmin=0, vmax=1, cbar=False, ax=axes[layer, head])
                axes[layer, head].axhline(num_txt_tokens, color='green', alpha=0.5)
                axes[layer, head].axvline(num_txt_tokens, color='green', alpha=0.5)
                for idx in comma_idx:
                    axes[layer, head].axhline(idx, color='red', alpha=0.5)
                    axes[layer, head].axvline(idx, color='red', alpha=0.5)
                for idx in period_idx:
                    axes[layer, head].axhline(idx, color='blue', alpha=0.5)
                    axes[layer, head].axvline(idx, color='blue', alpha=0.5)
        plt.savefig(figpath)