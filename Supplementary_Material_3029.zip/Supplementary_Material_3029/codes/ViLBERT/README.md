# Do Vision-Language Transformers Exhibit Visual Commonsense?

This repo is based on [ViLBERT](https://github.com/jiasenlu/vilbert_beta), you can refer to original repo for basic usage. 
In this repo, We provide the implementation code for each experiment in our paper on ViLBERT to validate our findings. 

### 1. Finetune w/o multimodal pretraining   
   ```
    python train_end2end.py --config cfgs/vcr/base_q2a_prec_wo_pretraining.yaml
   ```

### 2. Finetune w/o tag input
	- Use the 'replace_det_with_name_wo_tag' function insdead of 'replace_det_with_name' in 'vilbert/datasets/vcr_dataset.py'.
	- python train_task.py --bert_model bert-base-uncased --from_pretrained save/bert_base_6_layer_6_connect_freeze_0/pytorch_model_8.bin  --config_file config/bert_base_6layer_6conect.json  --learning_rate 2e-5 --num_workers 16 --tasks 1-2 --save_name pretrained

### 4. Randomly replace tags
- Set the flag `self.replace = True` in `vilbert/datasets/vcr_dataset.py`

### 5. Joint/Seperate Finetuning on subtasks
- __Joint__:
   ```
    python train_task.py --bert_model bert-base-uncased --from_pretrained save/bert_base_6_layer_6_connect_freeze_0/pytorch_model_8.bin  --config_file config/bert_base_6layer_6conect.json  --learning_rate 2e-5 --num_workers 16 --tasks 1-2 --save_name pretrained
   ```
- __Seperate__:
	- Question Answering:
	   ```
		python train_task.py --bert_model bert-base-uncased --from_pretrained save/bert_base_6_layer_6_connect_freeze_0/pytorch_model_8.bin  --config_file config/bert_base_6layer_6conect.json  --learning_rate 2e-5 --num_workers 16 --tasks 1 --save_name pretrained
	   ```
	- Answer Justification:
		```
		python train_task.py --bert_model bert-base-uncased --from_pretrained save/bert_base_6_layer_6_connect_freeze_0/pytorch_model_8.bin  --config_file config/bert_base_6layer_6conect.json  --learning_rate 2e-5 --num_workers 16 --tasks 2 --save_name pretrained
	   ```
  
### 6. Attention statistics
You can calculate the relevant statistical value of attention by following these steps:
- You need to store the attention maps produced on validation dataset at first. Each instance has following four fields,
  - `txt_ids`: textual tokens' id.
  - `tag_mask`: indicates the link between text token and relative object, provided by `co_attention_mask` in `vcr_dataset.py`
  - `att_txt2img`: co-attention weights using text as query and image as key.
  - `att_img2txt`: co-attention weights using image as query and text as key.
- Compute average attention weights and MRR of tags.
    ```
    python script/tag_attention_mrr.py
    ```
### 7. Proportion of correctly predicted instances from VL-BERT and the intersection of four states in VCR
You just need to save the logits for each sample and run `vcr/intersection.py`.
