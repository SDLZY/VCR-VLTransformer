
import numpy as np


def overlap_ratio(q2a_logits, q2a_label, qa2r_logits, qa2r_label):
    answer_preds = np.load(q2a_logits)
    answer_labels = np.load(q2a_label)
    rationale_preds = np.load(qa2r_logits)
    rationale_labels = np.load(qa2r_label)

    answer_hits = answer_preds.argmax(1) == answer_labels
    rationale_hits = rationale_preds.argmax(1) == rationale_labels

    both_true = np.mean(answer_hits & rationale_hits)
    only_answer_true = np.mean(answer_hits & ~rationale_hits)
    only_rationale_true = np.mean(~answer_hits & rationale_hits)
    both_false = np.mean(~answer_hits & ~rationale_hits)
    print(answer_hits.shape)
    print(answer_hits.sum())
    print(rationale_hits.shape)
    print(rationale_hits.sum())
    print("both true is {:.4f}, only_answer_true is {:4f}, only_rationale_true is {:4f} and both_false is {:4f}".format((answer_hits & rationale_hits).sum(), (answer_hits & ~rationale_hits).sum(), (~answer_hits & rationale_hits).sum(), (~answer_hits & ~rationale_hits).sum()))
    print("answer acc is {:4f} and rationale acc is {:4f}".format(np.mean(answer_hits), np.mean(rationale_hits)))
    print("both true is {:.4f}, only_answer_true is {:4f}, only_rationale_true is {:4f} and both_false is {:4f}".format(both_true, only_answer_true, only_rationale_true, both_false))



if __name__ == '__main__':
    overlap_ratio('val_logits_q2a_wo_tag.npy', 'val_labels_q2a_wo_tag.npy', 'val_logits_qa2r_wo_tag.npy', 'val_labels_qa2r_wo_tag.npy')