import os
import numpy as np
import pandas as pd
from tqdm.auto import tqdm


DIRNAME = 'save/VCR_Q-A-VCR_QA-R_bert_base_6layer_6conect-pretrained/attentions2/qa2r/'

if __name__ == '__main__':
    df = []
    start = 0
    end = 26534
    # for idx in tqdm(range(1)):
    # for idx in tqdm(range(26534)):
    for idx in tqdm(range(start, end)):
        for layer in range(6):
            inst = np.load(os.path.join(DIRNAME, str(layer), f'{idx}.npz'), allow_pickle=True)['arr_0'].item()
            for choice in range(4):
                txt_ids = inst['txt_ids'][choice]
                tag_mask = inst['tag_mask'][choice].T
                att = inst['att_txt2img'][choice]
                for tidx, oidx in zip(*tag_mask.nonzero()):
                    for head in range(8):
                        rank = att[head, tidx].argsort()[::-1].argsort()[oidx]
                        # rank = att[head, tidx][oidx]
                        prob = att[head, tidx, oidx]
                        df.append({
                            'idx': idx,
                            'choice': choice,
                            'layer': layer,
                            'head': head,
                            'tidx': tidx,
                            'oidx': oidx,
                            'rank': rank,
                            'attention': prob
                        })
    df = pd.DataFrame(df)
    df.to_csv(os.path.join(os.path.dirname(DIRNAME), f'tag_att_{start}-{end}.csv'))

